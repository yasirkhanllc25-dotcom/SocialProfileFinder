package com.example.socialprofilefinder

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {
    private lateinit var resultText: TextView
    private lateinit var searchButton: Button
    private var handles = mutableSetOf<String>()

    private val picker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { scanImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        resultText = findViewById(R.id.resultText)
        searchButton = findViewById(R.id.searchButton)

        findViewById<Button>(R.id.selectButton).setOnClickListener {
            picker.launch("image/*")
        }

        searchButton.setOnClickListener {
            // Backend/API integration belongs here.
            resultText.text = "Public-profile search is ready for backend/API integration."
        }
    }

    private fun scanImage(uri: Uri) {
        handles.clear()
        resultText.text = "Scanning picture…"
        val image = InputImage.fromFilePath(this, uri)

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                val text = result.text
                val regex = Pattern.compile("@[A-Za-z0-9._]{2,30}")
                val matcher = regex.matcher(text)
                while (matcher.find()) handles.add(matcher.group())
                scanBarcodes(image)
            }
            .addOnFailureListener {
                scanBarcodes(image)
            }
    }

    private fun scanBarcodes(image: InputImage) {
        BarcodeScanning.getClient().process(image)
            .addOnSuccessListener { codes ->
                val qrText = codes.mapNotNull { it.rawValue }.joinToString("\n")
                val output = buildString {
                    append("Visible handles:\n")
                    append(if (handles.isEmpty()) "None found" else handles.joinToString("\n"))
                    if (qrText.isNotBlank()) {
                        append("\n\nQR/barcode content:\n")
                        append(qrText)
                    }
                }
                resultText.text = output
                searchButton.isEnabled = handles.isNotEmpty() || qrText.isNotBlank()
            }
            .addOnFailureListener {
                resultText.text = if (handles.isEmpty()) "No public identifiers found." else
                    "Found handles:\n${handles.joinToString("\n")}"
                searchButton.isEnabled = handles.isNotEmpty()
            }
    }
}
