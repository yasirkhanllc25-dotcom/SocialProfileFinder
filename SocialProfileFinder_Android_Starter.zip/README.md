# Social Profile Finder — Android starter

This is a Play Store-oriented starter app.

## What it does
- Lets the user select a picture.
- Uses Google ML Kit OCR to read visible text.
- Detects QR/barcodes.
- Extracts visible @handles.
- Provides the foundation for searching public profiles.

## Important privacy boundary
The app intentionally does NOT perform face recognition or identify a stranger from their face to reveal their social-media accounts. Any future profile matching should use visible/public identifiers or an explicit account connection/consent flow.

## Open in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android 8.0+ device/emulator.
4. Build a signed AAB for Google Play when ready.

## Production work still needed
- Add a backend for public-profile search.
- Use official APIs where each platform permits searching.
- Add privacy policy, terms, data deletion, and consent screens.
- Add rate limiting and abuse prevention.
- Test Play Store Data Safety declarations.
